# Introduction 
The authorization server.

Implemented using OpenID Connect Client Initiated Backchannel Authentication (CIBA) Protocol.
https://openid.net/specs/openid-client-initiated-backchannel-authentication-core-1_0.html

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test

Dependencies
```
 yarn add -D babel-core babel-polyfill babel-preset-env babel-loader webpack webpack-cli webpack-merge flow-babel-webpack-plugin webpack-node-externals
```

